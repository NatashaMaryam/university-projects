
module imem (
    input [15:0] pc,            
    output reg [15:0] instr     // Instruction code
);

    always @(*) begin
        case(pc)
            
            // Format: [Opcode 4-bit] [Reg dest] [Reg 1] [Reg 2]
            
            // 0: ADD R1, R0, R0 (R1 = R0 + R0) 
            16'd0: instr = 16'b0000_0001_0000_0000; 
            
            // 1: LOAD R2, 5 (Load value 5 into R2) - Dummy Logic
            16'd1: instr = 16'b0010_0010_0000_0101; 
            
            // 2: SUB R3, R2, R1
            16'd2: instr = 16'b0001_0011_0010_0001; 
            
            // 3: STORE R3 to Memory
            16'd3: instr = 16'b0011_0011_0000_0000; 

            // Default: NOP (No Operation)
            default: instr = 16'b1111_0000_0000_0000;
        endcase
    end
endmodule