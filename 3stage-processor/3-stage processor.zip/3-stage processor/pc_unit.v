
module pc_unit (
    input clk,              
    input reset,            
    input stall,            
    output reg [15:0] pc    
);

    always @(posedge clk or posedge reset) begin
        if (reset) begin
            pc <= 16'd0;    
        end
        else if (stall == 0) begin
            pc <= pc + 1;   
        end
        
    end
endmodule