module processor (
    input clk,
    input reset
);

    wire [15:0] pc;
    wire [15:0] instruction;

    wire [3:0] opcode;
    wire [3:0] rd, rs1, rs2;

    wire [15:0] reg_data1, reg_data2;
    wire [15:0] alu_result;

    // FETCH STAGE
    pc_unit PC (
        .clk(clk),
        .reset(reset),
        .stall(1'b0),   // no stall for now
        .pc(pc)
    );

    imem IMEM (
        .pc(pc),
        .instr(instruction)
    );

    // DECODE STAGE
    assign opcode = instruction[15:12];
    assign rd     = instruction[11:8];
    assign rs1    = instruction[7:4];
    assign rs2    = instruction[3:0];

    reg_file RF (
        .clk(clk),
        .reset(reset),
        .read_reg1(rs1),
        .read_reg2(rs2),
        .write_reg(rd),
        .write_data(alu_result),
        .reg_write(1'b1),
        .read_data1(reg_data1),
        .read_data2(reg_data2)
    );

    // EXECUTE STAGE
    alu ALU (
        .a(reg_data1),
        .b(reg_data2),
        .alu_op(opcode),
        .result(alu_result)
    );

endmodule
