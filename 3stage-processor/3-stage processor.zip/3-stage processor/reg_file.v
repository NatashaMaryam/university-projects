module reg_file (
    input clk,
    input reset,
    input [3:0] read_reg1,
    input [3:0] read_reg2,
    input [3:0] write_reg,
    input [15:0] write_data,
    input reg_write,
    output reg [15:0] read_data1,
    output reg [15:0] read_data2
);

    // 16 registers
    reg [15:0] registers[0:15];
    
    // Loop variable (MODULE LEVEL - yahan rakho)
    integer k;

    // Read operation
    always @(*) begin
        read_data1 = registers[read_reg1];
        read_data2 = registers[read_reg2];
    end

    // Write operation
    always @(posedge clk) begin
        if (reset) begin
            // Reset all 16 registers
            for (k = 0; k < 16; k = k + 1) begin
                registers[k] <= 16'd0;
            end
        end
        else if (reg_write) begin
            registers[write_reg] <= write_data;
        end
    end

endmodule