`timescale 1ns / 1ps

module tb_processor;

    reg clk;
    reg reset;

    // Instantiate processor
    processor uut (
        .clk(clk),
        .reset(reset)
    );

    // Clock generation (10ns period)
    always #5 clk = ~clk;

    initial begin
        // Initialize
        clk = 0;
        reset = 1;

        // Apply reset
        #10;
        reset = 0;

        // Run simulation for some cycles
        #100;

        $finish;
    end

    // Monitor important internal signals
    initial begin
        $display("Time | PC | Instruction | Opcode | RD | RS1 | RS2 | ALU_Result");
        $monitor("%4t | %2d | %h | %b | %d | %d | %d | %h",
                 $time,
                 uut.pc,
                 uut.instruction,
                 uut.opcode,
                 uut.rd,
                 uut.rs1,
                 uut.rs2,
                 uut.alu_result);
    end

endmodule
