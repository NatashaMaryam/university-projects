module tb_reg_file;
    reg clk, reset, reg_write;
    reg [3:0] read_reg1, read_reg2, write_reg;
    reg [15:0] write_data;
    wire [15:0] read_data1, read_data2;

    reg_file uut (
        .clk(clk),
        .reset(reset),
        .read_reg1(read_reg1),
        .read_reg2(read_reg2),
        .write_reg(write_reg),
        .write_data(write_data),
        .reg_write(reg_write),
        .read_data1(read_data1),
        .read_data2(read_data2)
    );

    always #5 clk = ~clk;

    initial begin
        clk = 0;
        reset = 1;
        reg_write = 0;
        read_reg1 = 0;
        read_reg2 = 0;
        write_reg = 0;
        write_data = 0;

        #10;
        reset = 0;

        #10;
        write_reg = 4'd3;
        write_data = 16'hAAAA;
        reg_write = 1;
        #10;
        reg_write = 0;

        #10;
        read_reg1 = 4'd3;
        read_reg2 = 4'd0;

        #50;
        $stop;
    end

    initial begin
        $monitor("Time=%0t, R1=%h, R2=%h", $time, read_data1, read_data2);
    end
endmodule