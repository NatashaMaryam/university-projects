
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { PaperProvider } from 'react-native-paper';


// Import all screens
import HomeScreen from './HomeScreen';
import LoginScreen from './screens/LoginScreen';
import RegisterScreen from './screens/RegisterScreen';
import StudentDashboard from './screens/StudentDashboard';
import StudentGallery from './screens/StudentGallery'; // ✅ Student Gallery import
import AdminDashboard from './screens/admin/AdminDashboard';
import AdminAddEvent from './screens/admin/AdminAddEvent';
import AdminGallery from './screens/admin/AdminGallery';
import AdminManageChapters from './screens/admin/AdminManageChapters';
import AdminNominations from './screens/admin/AdminNominations';
import AdminUsers from './screens/admin/AdminUsers';
import ViewEventsScreen from './ViewEventsScreen';
import NominateScreen from './screens/NominateScreen';
import EventDetails from './screens/EventDetails';
import StorageViewer from './screens/admin/StorageViewer';

// Create Stack Navigator
const Stack = createNativeStackNavigator();

// Main App Component
export default function App() {
  return (
    <PaperProvider>
      <NavigationContainer>
        <Stack.Navigator
          initialRouteName="Home"
          screenOptions={{
            headerStyle: {
              backgroundColor: '#4CAF50',
            },
            headerTintColor: '#fff',
            headerTitleStyle: {
              fontWeight: 'bold',
            },
            headerShadowVisible: true,
          }}
        >
          {/* Main Navigation */}
          <Stack.Screen 
            name="Home" 
            component={HomeScreen}
            options={{ 
              title: 'STEM Society',
              headerShown: true,
            }}
          />
          
          {/* Auth Screens */}
          <Stack.Screen 
            name="Login" 
            component={LoginScreen}
            options={{ 
              title: 'Login',
              headerShown: true,
            }}
          />
          <Stack.Screen 
            name="Register" 
            component={RegisterScreen}
            options={{ 
              title: 'Register',
              headerShown: true,
            }}
          />
          <Stack.Screen
          name="StorageViewer"
          component={StorageViewer}
          options={{ title: 'AsyncStorage Viewer' }}
/>
          
          {/* Student Screens */}
          <Stack.Screen 
            name="StudentDashboard" 
            component={StudentDashboard}
            options={{ 
              title: 'Student Dashboard',
              headerShown: true,
              headerBackVisible: false, // Disable back button
            }}
          />
          <Stack.Screen 
            name="StudentGallery" 
            component={StudentGallery}
            options={{ 
              title: 'Event Gallery',
              headerShown: true,
            }}
          />
          <Stack.Screen 
            name="NominateScreen" 
            component={NominateScreen}
            options={{ 
              title: 'Nomination',
              headerShown: true,
            }}
          />
      
          
          {/* Admin Screens */}
          <Stack.Screen 
            name="AdminDashboard" 
            component={AdminDashboard}
            options={{ 
              title: 'Admin Dashboard',
              headerShown: true,
              headerBackVisible: false, // Disable back button
            }}
          />
          <Stack.Screen 
            name="AdminAddEvent" 
            component={AdminAddEvent}
            options={{ 
              title: 'Add New Event',
              headerShown: true,
            }}
          />
          <Stack.Screen 
            name="AdminGallery" 
            component={AdminGallery}
            options={{ 
              title: 'Gallery Management',
              headerShown: true,
            }}
          />
          <Stack.Screen 
            name="AdminManageChapters" 
            component={AdminManageChapters}
            options={{ 
              title: 'Manage Chapters',
              headerShown: true,
            }}
          />
          <Stack.Screen 
            name="AdminNominations" 
            component={AdminNominations}
            options={{ 
              title: 'Manage Nominations',
              headerShown: true,
            }}
          />
          <Stack.Screen 
            name="AdminUsers" 
            component={AdminUsers}
            options={{ 
              title: 'Manage Users',
              headerShown: true,
            }}
          />
          
          {/* Common Screens */}
          <Stack.Screen 
            name="ViewEvents" 
            component={ViewEventsScreen}
            options={{ 
              title: 'All Events',
              headerShown: true,
            }}
          />
          <Stack.Screen 
            name="EventDetails" 
            component={EventDetails}
            options={{ 
              title: 'Event Details',
              headerShown: true,
            }}
          />
        </Stack.Navigator>
      </NavigationContainer>
    </PaperProvider>
  );
}